USE master;
GO

IF EXISTS (SELECT * FROM sys.server_principals WHERE name = N'FilmProvider')
BEGIN
	DROP LOGIN FilmProvider;
END

IF EXISTS (SELECT * FROM sys.server_principals WHERE name = N'FilmManager')
BEGIN
	DROP LOGIN FilmManager;
END
GO

-- Check for the existence of the FilmDB and drop it if it exists
IF DB_ID('FilmDB') IS NOT NULL
BEGIN
    ALTER DATABASE [FilmDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [FilmDB];
    PRINT 'The database FilmDB has been deleted.';
END
ELSE
BEGIN
    PRINT 'The database FilmDB does not exist - no action taken.';
END
GO

-- Create FilmDB
CREATE DATABASE FilmDB;
GO

USE FilmDB;
GO

-- Create Genres Table
CREATE TABLE Genres (
    GenreID INT PRIMARY KEY,
    Name NVARCHAR(50),
    Description NVARCHAR(255)
);

-- Create Actors Table
CREATE TABLE Actors (
    ActorID INT PRIMARY KEY,
    Name NVARCHAR(100),
    Portrait NVARCHAR(255)
);

-- Create Films Table
CREATE TABLE Films (
    FilmID INT PRIMARY KEY,
    Title NVARCHAR(100),
    Director NVARCHAR(100),
    ReleaseDate DATE,
    DurationMinutes INT CHECK (DurationMinutes BETWEEN 0 AND 180)
);

-- Create a junction table for Films and Actors (Many-to-Many relationship)
CREATE TABLE FilmActors (
    FilmID INT NOT NULL,
    ActorID INT NOT NULL,
    PRIMARY KEY (FilmID, ActorID),
    CONSTRAINT FK_FilmActors_Film FOREIGN KEY (FilmID) REFERENCES Films(FilmID),
    CONSTRAINT FK_FilmActors_Actor FOREIGN KEY (ActorID) REFERENCES Actors(ActorID)
);

-- Add GenreID as a foreign key in the Films table
ALTER TABLE Films
ADD GenreID INT,
CONSTRAINT FK_Films_Genre FOREIGN KEY (GenreID) REFERENCES Genres(GenreID);
GO

USE FilmDB;
GO

-- Create Login and User for FilmProvider
CREATE LOGIN FilmProvider WITH PASSWORD = 'Passw0rd';
CREATE USER FilmProvider FOR LOGIN FilmProvider;
GRANT INSERT ON Films TO FilmProvider;
GO

-- Create Login and User for FilmManager
CREATE LOGIN FilmManager WITH PASSWORD = 'Passw0rd';
CREATE USER FilmManager FOR LOGIN FilmManager;
GRANT INSERT, UPDATE ON Films TO FilmManager;
GRANT INSERT, UPDATE ON Genres TO FilmManager;
GRANT INSERT, UPDATE ON Actors TO FilmManager;
GO

-- Full Backup to Disk
BACKUP DATABASE FilmDB
TO DISK = 'C:\SQL\Backups\FilmDB.bak' WITH INIT;
GO

