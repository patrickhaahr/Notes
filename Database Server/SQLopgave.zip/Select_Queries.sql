USE FilmDB;
GO

-- Query for Directors starting with 'B'
SELECT Title, Director FROM Films WHERE Director LIKE 'B%';

-- Query for Films and their Genres
SELECT f.Title, g.Name FROM Films f JOIN Genres g ON f.GenreID = g.GenreID;

-- Films over 120 minutes
SELECT COUNT(*) FROM Films WHERE DurationMinutes > 120;

-- Oldest Films
SELECT Title, MIN(ReleaseDate) FROM Films GROUP BY Title;
GO
